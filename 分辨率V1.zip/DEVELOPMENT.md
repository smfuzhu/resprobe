# ResProbe 开发与维护文档

> Windows 显示器分辨率变化探测、远程桌面诊断与虚拟显示器兜底工具
> 版本 1.0.0 ｜ 最后验证：2026-10-08

---

## 目录

1. [项目概览](#1-项目概览)
2. [运行环境与依赖](#2-运行环境与依赖)
3. [目录结构与模块划分](#3-目录结构与模块划分)
4. [核心功能技术实现](#4-核心功能技术实现)
5. [关键配置项](#5-关键配置项)
6. [接口与函数约定](#6-接口与函数约定)
7. [部署与启动](#7-部署与启动)
8. [常见问题排查](#8-常见问题排查)
9. [后续扩展注意事项](#9-后续扩展注意事项)
10. [附录：验证方法与证据文件](#10-附录验证方法与证据文件)

---

## 1. 项目概览

### 1.1 要解决的问题

被控电脑**物理关闭显示器**后，桌面分辨率从 1920×1080 掉到 1024×768，此时通过 ToDesk / 向日葵 / RustDesk 远程查看，看到的也是 1024×768。显示器重新开电后分辨率自动恢复。

### 1.2 已确认的根因（本机实测，2026-10-08）

```
物理按显示器电源键
    → HDMI HPD 拉低，链路断开
    → 主机读不到 EDID（DISPLAY1/2/3 的 EDID 全部消失）
    → 监视器设备节点消失、驱动首选模式降级 1920x1080 → 1024x768
    → 模式表从 298 项退化为 32 项「通用回退列表」
    → 系统回退到默认模式 1024x768
    → 远程软件只是被动跟随主机帧缓冲，不是诱因
```

**已排除的三个误判方向**（每个都实际误导过一次排查）：

| 排除项 | 实测结论 |
|---|---|
| 系统省电关屏 | `SC_MONITORPOWER` 关屏**不会**断链，EDID 仍可读，分辨率保持 1920×1080 |
| 显示器电源通知 | 物理关屏时 `GUID_CONSOLE_DISPLAY_STATE` **一次都不触发**，只有拓扑推断能捕获 |
| 软件强行回写 | 链路断开期间 `CDS_TEST` 预检通过，但三种 DEVMODE 变体实际应用全部 `DISP_CHANGE_FAILED` |

### 1.3 解决方案总览

工具分两层：

- **诊断层**：探测拓扑 / EDID / 事件 / 会话 / 远程软件痕迹，对整条时间线做根因判定，输出结构化 JSON 报告。
- **兜底层**：借助**间接显示驱动（IDD）虚拟显示器**，在物理链路断开时把虚拟屏提升为参考分辨率主屏并摘除死输出，使桌面恒为 1920×1080。

---

## 2. 运行环境与依赖

### 2.1 目标平台

| 项 | 要求 |
|---|---|
| 操作系统 | Windows 10 / 11 x64（依赖 WDDM 显示配置 API 与 `IddCx` 间接显示框架） |
| 语言标准 | C++17 |
| 编译器 | MinGW-w64 g++ 15.2.0（本机 `C:\mingw64\bin`）；代码同时兼容 MSVC 2019+ |
| 构建工具 | `mingw32-make`（无 CMake 依赖，刻意保持零第三方构建系统） |
| 权限 | 只读探测：普通用户即可。回写 / 虚拟屏操作：**需管理员** |

### 2.2 链接的系统库

```
user32 gdi32 setupapi wtsapi32 powrprof advapi32 shell32 ole32 oleaut32
```

全部为系统自带库，**无任何第三方运行时依赖**（`-static-libgcc -static-libstdc++`）。

### 2.3 关键编译宏

```makefile
-DWIN32_LEAN_AND_MEAN   # 精简 win32 头；副作用见 §9.1
-DNOMINMAX              # 避免 windows.h 的 min/max 宏破坏 <algorithm>
-DUNICODE -D_UNICODE
-D_WIN32_WINNT=0x0A00   # QDC_ALL_PATHS / QueryDisplayConfig / SetDisplayConfig 需要
-DWINVER=0x0A00
```

### 2.4 外部组件（虚拟屏兜底层）

| 组件 | 说明 |
|---|---|
| **usbmmidd v2** | Amyuni 的 UMDF 间接显示驱动，`usbmmIdd.dll` 经 **WHQL 签名**（Microsoft Windows Hardware Compatibility Publisher） |
| 驱动包位置 | **随项目内置**：`driver\usbmmidd_v2\`（源包来自 `https://www.amyuni.com/downloads/usbmmidd_v2.zip`） |
| 离线部署 | 内置包使整个项目可离线部署。**不要**放回 `C:\Temp`：那是临时目录，随时可能被清理工具或用户删除 |
| 关键工具 | `deviceinstaller64.exe`（官方控制工具，本身未签名，非驱动） |
| 驱动实例 | `ROOT\DISPLAY\0001`，软件键 `Control\Class\{4D36E968-...}\0005` |

> 备选：向日葵自带 `OrayIddDriver`（已安装且 Started），但其虚拟显示器**必须由向日葵用户态程序按需实例化**，外部无法强制创建，因此本项目改用 usbmmidd。

---

## 3. 目录结构与模块划分

```
d:\nodejs\分辨率\
├─ src\
│   ├─ common.h       全局数据结构 + 手工声明的 GUID（不依赖 initguid/devguid）
│   ├─ util.{h,cpp}   编码转换 / 时间 / 枚举名 / JSON 转义 / 日志
│   ├─ edid.{h,cpp}   EDID 读取（SetupAPI）与解析
│   ├─ display.{h,cpp}显示拓扑枚举 / 模式表 / 快照 / 差分
│   ├─ session.{h,cpp}会话环境探测 + 远程软件特征识别
│   ├─ verify.{h,cpp} 模式验证 / 回写 / 布局重排 / 输出摘除 / 虚拟屏提升
│   ├─ verdict.{h,cpp}时间线根因判定
│   ├─ watcher.{h,cpp}隐藏顶层窗口 + 事件监听 + 自动守卫
│   ├─ report.{h,cpp} 控制台输出 + JSON 报告
│   └─ main.cpp       CLI 解析与各子命令编排
├─ Makefile            构建规则（-MMD -MP 自动依赖；make 默认按此名查找，保留英文）
├─ 编译.bat            【脚本】构建入口（注入 MinGW PATH）
├─ 安装.cmd            【脚本】幂等安装：驱动包 + 设备节点 + 虚拟屏 + 拓扑
├─ 卸载.cmd            【脚本】卸载（/full 移除驱动，/purge 清文件）
├─ 一次性启动.cmd       【脚本】一次性就绪：无显示器 / 不再接回显示器
├─ 常驻守卫.cmd         【脚本】常驻守卫（默认开机启动方式）
├─ 开机自启.cmd         【脚本】开机自启注册 / 注销 / 查询
├─ 脚本编码修复.ps1     【工具】脚本编码归一化 / 纯 ASCII 校验（见 §8.6）
├─ driver\usbmmidd_v2\ 内置的虚拟显示驱动包（离线可用，见 §2.4）
├─ samples\            对端摘要样例（用于演示双端比对）
├─ OUT\                统一输出目录（日志 / 显式指定的 JSON 报告）
├─ build\              目标文件与依赖文件
├─ resprobe.exe        产物（控制台子系统）
└─ DEVELOPMENT.md       本文档
```

> ### 脚本编码模型（务必遵守，这是最容易踩的坑）
>
> 规则只有两条，但都不能破：
>
> 1. **脚本文件名可以是中文**（文件系统按 UTF-16 处理，用户手输也没问题）。
> 2. **脚本内容必须是纯 ASCII**（< 0x80），UTF-8 保存、**不带 BOM**。
>
> **为什么内容是纯 ASCII**：cmd.exe 按**当前 OEM 代码页**（本机 936）解析批处理内容，
> 并且是**按字节偏移**逐行重读文件的。一个多字节字符会让这个偏移错位，于是注释行的
> 后半截被当成新命令执行 —— 典型报错：
>
> ```
> 'l），变量才会继承到调用者。' is not recognized as an internal or external command
> ```
>
> **`chcp 65001` 救不了这个问题**：它只改变已读入字节的解释方式，改变不了「按字节偏移
> 重读」这个机制。实测在 `for` 循环块、`if` 块里都会翻车。唯一稳的做法是内容全 ASCII。
>
> **连带约束**：既然内容是纯 ASCII，就**不能 `call "配置.cmd"`** —— 这一行本身含中文，
> 又变成非 ASCII 了。所以：
>
> - 共享配置块**内联复制**在每个脚本里（搜索 `CONFIG BLOCK` 定位），改动时需同步 6 个文件；
> - 管理员检查内联在每个脚本里（`fltmc` 三行），不再有 `管理员检查.cmd`；
> - `开机自启.cmd` 需要在运行时定位另外两个脚本，改为**按文件内容里的 ASCII 标记行**
>   （`RESPROBE-ROLE:once` / `RESPROBE-ROLE:guard`）扫描发现，匹配锚定行首且跳过自身，
>   否则它自己注释里提到的那串标记就会自匹配。
>
> **禁止事项**：不要在 `.cmd` 里写中文（哪怕是注释或 `echo`）。中文说明一律放本文档。
>
> **检查工具**：
>
> ```
> powershell -NoProfile -ExecutionPolicy Bypass -File 脚本编码修复.ps1
> ```
>
> 它会对目录下所有 `.cmd` / `.bat`：去 BOM →（必要时）GBK 转 UTF-8 → 去掉多余的
> `chcp 65001` 行 → 以 UTF-8 无 BOM 写回 → **逐个报告残留的非 ASCII 字符及其行首位置**。
> 全部干净时退出码 0，发现非 ASCII 时退出码 1。改完脚本建议跑一次。

### 3.1 模块依赖关系

```
main.cpp
  ├─ display ── edid ── util
  ├─ session ── util
  ├─ verify ── display, util
  ├─ watcher ── display, verify, report, util
  ├─ verdict ── util
  └─ report ── util

common.h  ← 所有模块的公共基础（必须作为每个 TU 的第一个头文件）
```

### 3.2 各模块职责边界

| 模块 | 只做 | 不做 |
|---|---|---|
| `edid` | 读注册表 EDID、解析字节 | 不关心显示器是否激活 |
| `display` | 枚举路径、关联 EDID、快照、差分 | 不改动系统状态 |
| `session` | 查询会话、扫描进程/服务/设备特征 | 不判断因果关系 |
| `verify` | 所有**会改变系统状态**的动作集中在此 | 不做判定 |
| `verdict` | 纯函数式判定 | 不调用任何 Win32 状态修改 API |
| `watcher` | 消息循环、事件合并、守卫调度 | 不直接调 Win32 显示 API（走 verify） |
| `report` | 序列化与打印 | 不含业务逻辑 |

> **维护约定**：所有会改变系统状态的调用（`ChangeDisplaySettingsEx` / `SetDisplayConfig` / `DetachOutputs`）必须收敛在 `verify.cpp`，禁止散落到其它模块。这是保证"诊断模式绝不误改系统"的结构性约束。

---

## 4. 核心功能技术实现

### 4.1 显示拓扑探测（`display.cpp`）

**主数据源是 DisplayConfig，不是 GDI。**

```cpp
GetDisplayConfigBufferSizes(QDC_ALL_PATHS, &numPaths, &numModes);
QueryDisplayConfig(QDC_ALL_PATHS, &numPaths, paths, &numModes, modes, nullptr);
```

用 `QDC_ALL_PATHS` 而非 `QDC_ONLY_ACTIVE_PATHS`，才能看到"已连接但未激活"的输出路径 —— 这是识别可激活虚拟显示的前提。

每条路径采集成一个 `DisplayTarget`：

| 字段组 | 来源 |
|---|---|
| `active` / `targetAvailable` / `targetStatusFlags` / `outputTechnology` | `p.flags`、`p.targetInfo.*` |
| `monitorFriendlyName` / `monitorDevicePath` / `edidManufactureId` / `edidProductCodeId` | `DISPLAYCONFIG_DEVICE_INFO_GET_TARGET_NAME` |
| `gdiDeviceName` | `DISPLAYCONFIG_DEVICE_INFO_GET_SOURCE_NAME` → `viewGdiDeviceName` |
| `hasPreferred` / `preferredWidth/Height` | `DISPLAYCONFIG_DEVICE_INFO_GET_TARGET_PREFERRED_MODE` |
| 当前分辨率 / 刷新率 | `modes[p.sourceInfo.modeInfoIdx]` 与 `modes[p.targetInfo.modeInfoIdx]` |
| GDI 适配器状态 | `EnumDisplayDevicesW(nullptr, i, ...)` 按 `DeviceName` 匹配 |
| 桌面矩形 | `EnumDisplayMonitors` + `GetMonitorInfoW` |
| 模式表 | `EnumDisplaySettingsExW` 逐索引枚举 |

**重要：`QueryDisplayConfig` 的 `modeInfoArray` 用同一个数组承载 SOURCE 与 TARGET 两类模式信息，靠 `infoType` 区分，索引由 `modeInfoIdx` 给出。**

#### 输出过滤

`QDC_ALL_PATHS` 在本机返回 **146 条路径**，其中绝大多数是占位路径。默认只保留"有意义"的输出：

```cpp
bool meaningful = t.active || !t.monitorDevicePath.empty() ||
                  t.edid.present || t.monitorDeviceNodePresent;
```

`EnumerateDisplays(..., includePlaceholderPaths = true)` 可返回全量（`paths` 子命令用）。

**模式表只对 `active` 输出枚举** —— 否则 100 条占位路径 × 数百模式会让报告爆炸。

#### 快照与差分

`CaptureSnapshot()` 产出 `DisplaySnapshot`（含 `powerState` / `powerStateInferred` / `primaryMode` / `totalPathCount` / `targets`）。

`DiffSnapshots()` 以 **GDI 设备名**（无则用 `适配器LUID:targetId`）为键做配对，产出两份人类可读证据：

- `changedFields`：机器可读的字段列表，如 `\\.\DISPLAY1.edidPresent`
- `transitions`：人类可读的迁移，如 `\\.\DISPLAY1: EDID present -> absent`

### 4.2 EDID 读取与关联（`edid.cpp`）

**读取路径**：`SetupDiGetClassDevsW(GUID_DEVCLASS_MONITOR)` → 逐设备 `SetupDiOpenDevRegKey(DIREG_DEV)` → `RegQueryValueExW(L"EDID")`。

**解析**：检查 8 字节魔数 `00 FF FF FF FF FF FF 00`，提取厂商 PNP 码、产品码、序列号、扩展块数、四个 18 字节描述符（`0xFC` 显示器名、`0xFF` 序列号、描述符 0 为首选时序）。原始字节以十六进制保留作为证据。

**关联策略（关键设计）**：

```cpp
// 1) 优先用规范化后的设备实例 ID 精确匹配
//    \\?\DISPLAY#VSC3C8E#4&1440d7a&0&UID198195#{guid}
//    →  DISPLAY\VSC3C8E\4&1440d7a&0&UID198195
// 2) 只有当 DisplayConfig 完全没给设备路径时，才退化为「厂商+产品码」匹配，
//    且要求候选唯一
```

> **为什么必须这样**：如果无条件用厂商+产品码兜底，"显示器断电导致设备节点消失"会被另一台同型号显示器顶替，**直接掩盖故障信号**。

### 4.3 事件监听（`watcher.cpp`）

#### 4.3.1 窗口类型（曾踩坑）

**必须创建普通顶层窗口，不能创建 message-only 窗口（`HWND_MESSAGE`）。** 广播消息（`WM_DISPLAYCHANGE` / `WM_DEVICECHANGE` / `WM_SETTINGCHANGE`）不会投递给 message-only 窗口。窗口创建后**不调用 `ShowWindow`** 即保持隐藏。

#### 4.3.2 监听的事件源

| 消息 | 说明 |
|---|---|
| `WM_DISPLAYCHANGE` | 分辨率/色深变化，`LOWORD(lp)`×`HIWORD(lp)` 为新分辨率 |
| `WM_DEVICECHANGE` | `DBT_DEVICEARRIVAL` / `DBT_DEVICEREMOVECOMPLETE` / `DBT_DEVNODES_CHANGED` |
| `WM_SETTINGCHANGE` | 工作区/系统设置变化 |
| `WM_POWERBROADCAST` | `PBT_POWERSETTINGCHANGE` → `GUID_CONSOLE_DISPLAY_STATE` 显示器开关 |
| `WM_WTSSESSION_CHANGE` | 远程连接 / 断开 / 锁定（需 `WTSRegisterSessionNotification`） |

注册的三个通知：

```cpp
RegisterPowerSettingNotification(hwnd_, &kGuidConsoleDisplayState, DEVICE_NOTIFY_WINDOW_HANDLE);
RegisterDeviceNotificationW(hwnd_, &filter /*GUID_DEVINTERFACE_MONITOR*/, DEVICE_NOTIFY_WINDOW_HANDLE);
WTSRegisterSessionNotification(hwnd_, NOTIFY_FOR_THIS_SESSION);
```

任一注册失败都只打印提示并继续 —— 因为告警路径不能因为某个通知不可用就整体失效。

#### 4.3.3 事件合并（曾踩坑）

变化爆发时（显示器断电会让 HDMI 链路反复协商）事件密集到达。合并窗口若无上限，采样会被**无限推迟**，整个变化过程被完全漏掉。

```cpp
pendingAt_ = min(now + settleMs, pendingFirstMs_ + settleMs * 3);
```

并在消息循环退出时**强制采样一次**（`final-state`），确保终态被记录。

#### 4.3.4 消息循环

```cpp
while (!StopRequested()) {
    DWORD wait = MsgWaitForMultipleObjects(0, nullptr, FALSE, 250, QS_ALLINPUT);
    if (wait == WAIT_OBJECT_0) { /* PeekMessage / TranslateMessage / DispatchMessage */ }
    // 事件合并窗口到期 → TakeSample
    // 心跳周期到期 → TakeSample("heartbeat")
    // 时长上限到期 → break
}
```

`Ctrl+C` 由 `SetConsoleCtrlHandler` 置标志位，主循环检测后优雅收尾（写报告）。

### 4.4 会话与远程软件识别（`session.cpp`）

- 会话：`GetSystemMetrics(SM_REMOTESESSION)`、`ProcessIdToSessionId`、`WTSGetActiveConsoleSessionId`、`WTSQuerySessionInformationW`（用户名/工作站/域名/客户端名/协议类型/连接状态/客户端地址）。
- 远程软件特征：按 **显示适配器设备、监视器设备、显示适配器 SetupAPI 设备、进程、服务** 五个面扫描，关键词表 `kVendors[]` 覆盖 ToDesk / 向日葵(Oray) / AnyDesk / TeamViewer / RustDesk / Radmin / VNC / Parsec / DisplayLink / Indirect Display / usbmmidd 等。
- 额外判据：`DISPLAY_DEVICE_MIRRORING_DRIVER` 标志、输出技术为 `INDIRECT_WIRED/INDIRECT_VIRTUAL`、SetupAPI 枚举器为 `ROOT`（软件设备）。

> 短关键词（如 `idd`）会误命中 `Middleware`。已将其收紧为 `idddriver` / `idd driver`。**新增关键词时务必确认不会命中常见英文单词。**

### 4.5 模式可用性验证（`verify.cpp`）

```cpp
DEVMODEW dm{}; dm.dmSize = sizeof(dm);
dm.dmFields = DM_PELSWIDTH | DM_PELSHEIGHT;
dm.dmPelsWidth = w; dm.dmPelsHeight = h;
LONG rc = ChangeDisplaySettingsExW(dev, &dm, nullptr, CDS_TEST, nullptr);
```

> **`CDS_TEST` 通过 ≠ 实际可应用。** 它只校验模式在列表内合法，不碰硬件。链路断开时 `CDS_TEST` 返回成功而实际应用返回 `DISP_CHANGE_FAILED`。所有面向用户的界面文案都必须带上这个限定。

回写 `ApplyDisplayMode()` 会依次尝试三种 DEVMODE 组合，并记录每次的返回码：

1. 完整 DEVMODE（含色深/刷新率，从模式表反查）+ 写入注册表
2. 完整 DEVMODE，不写注册表
3. 最小 DEVMODE（仅宽高）

**从不设置 `DM_POSITION`**，以免意外打乱多屏布局。

### 4.6 时间线根因判定（`verdict.cpp`）

**判定基于整条时间线的最差状态，而不是首尾快照对比。** 早期实现只比较首尾，导致"掉下去又恢复"的故障被误报为 `NOT_REPRODUCED`。

```cpp
// 去重构建时间线：基线 + 各事件快照 + 最终状态
for (i = 1; i < timeline.size(); ++i)
    ComparePair(*timeline[i-1], *timeline[i], refW, refH, s);
// 再叠加「当前状态证据」，覆盖没有捕获到变化过程的情况
```

`Signals` 聚合的关键量：`edidLost` / `resolutionDrop` / `targetDisappeared` / `referenceLost` / `preferredCollapsed` / `genericFallbackListSeen` / `virtualDisplayActive` / `remoteSession` / 主输出分辨率的 baseline/worst/last 三元组 / `dropTransitions` / `recovered`。

判定优先级：**双端比对 > 单机时间线**。

#### 判定码表

| code | 含义 | blame | 典型置信度 |
|---|---|---|---|
| `LINK_LEVEL_FALLBACK` | EDID/设备节点丢失 + 分辨率下降 | link | high |
| `LINK_LEVEL_FALLBACK_SUSPECTED` | 分辨率下降 + 输出从拓扑消失，但无 EDID 直接证据 | link | medium |
| `EDID_UNSTABLE_LINK` | EDID 丢失但分辨率尚未下降 | link | medium |
| `REFERENCE_MODE_UNAVAILABLE` | 模式表丢失参考分辨率 | link | medium |
| `RESOLUTION_FALLBACK_NO_EDID_EVIDENCE` | 降到默认回退级别，但没抓到 EDID 证据 | unknown | medium |
| `DISPLAY_MODE_CHANGED` | 分辨率下降但未落入默认回退模式 | unknown | low |
| `REMOTE_TAKEOVER_NORMAL` | 主机降级、远端正常 —— 虚拟分辨率接管属预期 | remote-software | medium |
| `REMOTE_SOFTWARE_FAULT` | 主机正常、远端降级 | remote-software | high |
| `REMOTE_MISMATCH` | 双端不一致但无法进一步定位 | remote-software | medium |
| `CONSISTENT` | 双端一致且正常 | none | high |
| `NOT_REPRODUCED` | 未观测到异常 | none | medium |
| `NO_DATA` / `UNDETERMINED` | 数据不足 | unknown | — |
| `PATHS_LISTED` | `paths` 子命令专用，仅表示已列出路径，非判定结论 | unknown | — |

### 4.7 虚拟显示器与自动守卫

#### 4.7.1 激活机制

usbmmidd 的虚拟显示器**只能通过官方工具激活**：

```bat
deviceinstaller64.exe enableidd 1     :: 每次调用添加一块，最多 4 块
deviceinstaller64.exe enableidd 0     :: 每次调用移除一块
```

**实测无效的几种尝试**（不要再重复）：

- 仅用 `devcon install` 创建设备 → 设备 `Started`，但 `targetAvailable` 全为 `false`，零虚拟显示器
- 往 `Enum\ROOT\DISPLAY\0001\Device Parameters` 写 `Parameters\Monitors` → 无效
- 往 `Control\Class\{4D36E968-...}\0005` 写 `Parameters\Monitors` → 无效
- `pnputil /restart-device` 重启设备 → 无效

分辨率表实际位置（**仅在需要改可选分辨率表时使用**）：

```
HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WUDF\Services\usbmmIdd\Parameters\Monitors
  (默认值) = 默认显示器分辨率，例如 "1920,1080"
  0..9     = 可选分辨率表，例如 0="1024,768" 5="1920,1080"
```

> **虚拟显示器不跨重启保留。** 重启后必须重跑 `enableidd`，见 `一次性启动.cmd` / `常驻守卫.cmd`。

#### 4.7.2 两种拓扑，用途不同

| 拓扑 | 命令 | 适用 |
|---|---|---|
| **复制（镜像）** | `vdisplay --yes --mirror` | 显示器常开。桌面尺寸保持 1920×1080，本地画面无窗口乱跳 |
| **扩展 + 提升** | `vdisplay --yes --promote` | 显示器会断电。虚拟屏设为 1920×1080 主屏，死输出摘除 |

> **镜像不能用于断电场景**：克隆组取两个输出的**共同分辨率**，物理那一份一退化到 1024×768，整个 source 就被拉低，随后 Windows 还会把它拆成扩展模式。**必须先让虚拟屏到 1920×1080 再克隆**，否则桌面会被压到 1024×768。

#### 4.7.3 自动守卫（`watch --guard`）

在每次 `TakeSample` 之后评估，触发条件为**条件驱动 + 冷却窗口**（不是一次性标志）：

```cpp
bool needAction = (!alreadyOk) || deadPhysical;
   // alreadyOk   : 主屏已达到参考分辨率
   // deadPhysical: 存在 active 且 !edid.present 的非虚拟输出
if (hasVirtual && needAction && cooldownPassed /*8s*/) {
    PromoteVirtualDisplay(refW, refH, /*detachDeadOutputs=*/true);
}
```

动作序列（`PromoteVirtualDisplay`）：

1. 找出**活动中的虚拟显示输出**（按适配器描述匹配虚拟显示特征）
2. `ArrangeDesktopLayout()`：虚拟屏落 `(0,0)` 并设为参考分辨率，其余输出依次右移
3. `DetachOutputs()`：把所有 `!edid.present` 的非虚拟输出从桌面配置剔除
4. 复核并输出结果

**死输出的正确判据是 `edid.present == false`，不是 `monitorDeviceNodePresent == false`。** 显示器断电后监视器设备节点**仍然存在**于注册表中，早期据此判断导致摘除从未触发。

#### 4.7.4 输出摘除必须用 SetDisplayConfig

```cpp
// 错误做法（返回 DISP_CHANGE_SUCCESSFUL，但输出根本没被摘除）：
ChangeDisplaySettingsExW(dev, nullptr, nullptr, CDS_UPDATEREGISTRY, nullptr);

// 正确做法：
QueryDisplayConfig(QDC_ONLY_ACTIVE_PATHS, ...);          // 取当前活动路径
// 按 GDI 源名剔除目标路径，保留原模式数组（modeInfoIdx 仍有效）
SetDisplayConfig(keptPaths, modes,
                 SDC_APPLY | SDC_USE_SUPPLIED_DISPLAY_CONFIG | SDC_ALLOW_CHANGES);
```

内置保护：`kept` 为空时返回 `ERROR_INVALID_PARAMETER`，**绝不允许摘成空桌面**。

#### 4.7.5 拓扑分类的一处重要陷阱（`EvaluateTopology`）

判断"哪些输出是虚拟屏、哪些是断链死输出"看起来简单，实际有两个坑：

1. **适配器路径会串味。** 先用 `DISPLAYCONFIG_DEVICE_INFO_GET_ADAPTER_NAME` 取适配器设备路径，
   再用 `ROOT#DISPLAY` 等特征区分物理/软件适配器。注意该查询的 **`header.id` 必须传 0**
   （传 target id 会让所有适配器都返回同一个路径）。
2. **克隆（镜像）拓扑下适配器路径根本不可用。** 克隆时多个输出共用同一个 GDI 源，
   DisplayConfig 会把克隆目标报在**源适配器**上 —— 此时无论用 `gdiDeviceString` 还是
   `adapterDevicePath`，虚拟屏都长得和物理屏一模一样。

因此 `EvaluateTopology` 在"无 EDID 且不属于已知虚拟适配器"这一支上，改用
**当前分辨率是否低于参考分辨率**来区分：

```cpp
UINT64 area = (UINT64)t.width * (UINT64)t.height;
UINT64 refArea = (UINT64)refW * (UINT64)refH;
if (area > 0 && area < refArea) { ++deadPhysicalCount; }   // 回退了 -> 断链死输出
else                            { ++activeVirtualCount; }  // 仍在参考分辨率 -> 虚拟屏
```

这也解释了为什么 `ensure` 的就绪判据只看「主屏分辨率 + 有无断链死输出」，而**不**

依赖虚拟屏计数 —— 后者在克隆态下不可靠。虚拟屏计数仅用于 `ensure` 判断"要不要提示去
`enableidd`"，以及日志展示。

---

## 5. 关键配置项

### 5.1 命令行选项

| 选项 | 适用 | 默认 | 作用 |
|---|---|---|---|
| `--reference WxH` | 全部 | `1920x1080` | 参考健康分辨率。判定、验证、提升都以它为准 |
| `--out FILE` | 全部 | **不写 JSON** | 显式指定才写报告；纯文件名会落到输出目录，同时派生 `<同名>.peer.json` |
| `--out-dir DIR` | 全部 | `<程序目录>\OUT` | 覆盖输出目录 |
| `--no-cds-test` | 全部 | 关闭（即默认执行） | 跳过 `CDS_TEST` 只读探测 |
| `--verbose` | 全部 | 否 | 输出更详细信息；`paths` 下会列出全部占位路径 |
| `--peer FILE` | verify/watch | — | 对端 `*.peer.json`，启用双端比对 |
| `--mode auto\|mirror\|promote` | ensure | `auto` | `auto`=有健康物理屏则镜像、否则提升虚拟屏 |
| `--duration SEC` | watch | `0`（直到 Ctrl+C） | 监听时长上限 |
| `--interval SEC` | watch | `30` | 心跳采样间隔，`0` 关闭 |
| `--settle MS` | watch | `800` | 事件后等待驱动稳定的毫秒数；合并窗口上限为其 3 倍 |
| `--guard` | watch | 否 | 启用自动守卫（断链自动提升虚拟屏） |
| `--yes` | vdisplay/restore | 否 | **必需**，确认执行系统状态变更 |
| `--mirror` | vdisplay | 否 | 复制（镜像）拓扑 |
| `--promote` | vdisplay | 否 | 提升虚拟屏为主屏 + 摘除死输出 |

### 5.2 需要留意的默认常量

| 常量 | 位置 | 值 | 说明 |
|---|---|---|---|
| `kMaxEvents` | `watcher.cpp` | 1000 | 事件上限；达到后用最新状态覆盖尾条目，保证有界且终态准确 |
| `kMaxDeferFactor` | `watcher.cpp` | 3 | 事件合并窗口相对 `settleMs` 的最大延长倍数 |
| `kGuardCooldownMs` | `watcher.cpp` | 8000 | 守卫动作冷却，防止抖动期反复触发 |
| `kMaxModeEnumeration` | `display.cpp` | 4000 | 单输出模式枚举上限 |
| 模式表保留上限 | `display.cpp` | 64 | 每输出保留的唯一分辨率条数 |
| EDID 原始字节上限 | `edid.cpp` | 256 字节 | 且**仅活动输出**保留 `rawHex`，避免同一显示器重复多份 |

### 5.3 注册表 / 系统配置

| 位置 | 作用 |
|---|---|
| `HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WUDF\Services\usbmmIdd\Parameters\Monitors` | usbmmidd 虚拟显示器分辨率表 |
| `Control\Class\{4D36E968-E325-11CE-BFC1-08002BE10318}\000X` | 显示类软件键（`0005` = usbmmidd，`0002` = Oray IDD） |
| `Enum\ROOT\DISPLAY\0000` / `0001` | Oray IDD / usbmmidd 设备实例 |

### 5.4 部署脚本一览

| 脚本 | 作用 | 关键参数 |
|---|---|---|
| `安装.cmd` | **幂等**安装（详见下方 8 步） | 无 |
| `卸载.cmd` | 注销任务 → 停守卫 → 移除虚拟屏 | `/full` 移除驱动；`/purge` 再清文件与内置驱动包 |
| `一次性启动.cmd` | 一次性就绪（无显示器 / 不再接回显示器） | `/status` 只看状态 |
| `常驻守卫.cmd` | 常驻守卫（**默认开机启动方式**） | `/bg` 后台；`/json` 额外写状态 JSON |
| `开机自启.cmd` | 注册 / 注销 / 查询开机自启 | `/mode guard`（默认）`\|once`；`/status`；`/remove` |
| `编译.bat` | 构建入口 | `clean` 清理 |
| `脚本编码修复.ps1` | 脚本编码归一化 + 纯 ASCII 校验（见 §8.6） | 无 |

> 共享配置（路径 / 参考分辨率 / 驱动包位置 / 任务名 / 退出码）**内联在每个脚本里**，
> 搜索 `CONFIG BLOCK` 即可定位。改动配置需要同步 6 个 `.cmd` / `.bat` —— 这是
> 「内容必须纯 ASCII，因而无法 `call` 中文名配置文件」换来的代价，见 §3 编码模型。

#### `安装.cmd` 的 8 个步骤与幂等判据

新机上驱动、设备节点、虚拟屏**都不存在**，本脚本负责从零装出来。
每一步都先查状态再动作，因此可重复执行：

| 步骤 | 动作 | 幂等判据 |
|---|---|---|
| 1 | 确保 `resprobe.exe` | 已存在则跳过；缺失则调 `mingw32-make` 现场编译 |
| 2 | 确保 `OUT\` | `mkdir` 失败即已存在 |
| 3 | **定位驱动包**（三级回退） | ①内置 `driver\usbmmidd_v2\` ②迁移旧位置 `C:\Temp\...` ③联网下载 |
| 4 | **创建设备节点** | `pnputil /enum-devices /class Display` 里出现 `USB Mobile Monitor` 则跳过 |
| 5 | 写虚拟显示器分辨率表 | `reg add /f` 覆盖写，天然幂等 |
| 6 | **激活恰好一块虚拟显示器** | **依赖 `resprobe ensure` 返回 20**；已有虚拟屏就不再 `enableidd 1` |
| 7 | 应用显示拓扑 | `resprobe ensure` 内部先判"已就绪"再决定动作 |
| 8 | 汇总结果与列出同目录脚本 | — |

> **第 4 步是全新机器上的关键**：`pnputil /add-driver` 只把驱动包放进 DriverStore，
> **不会创建 ROOT 枚举的设备节点**。必须用驱动包自带的
> `deviceinstaller64.exe install usbmmIdd.inf usbmmIdd` 才行。
> 缺了这一步，第 6 步的 `enableidd 1` 会静默失效（设备在跑但一个虚拟显示器都没有）。

> **第 3 步为什么优先用内置包**：`C:\Temp` 是临时目录，随时可能被清理工具或用户删除。
> 驱动包已随项目内置在 `driver\usbmmidd_v2\`，**离线机器直接可用**；只有在既没有内置包、
> 也没有旧位置副本时才联网下载。要做纯离线部署，把整个项目目录拷过去即可。

#### `开机自启.cmd` 注册的两个登录任务（默认 `guard` 模式）

| 任务名 | 目标 | 延迟 | 原因 |
|---|---|---|---|
| `ResProbe VDisplay Init` | `一次性启动.cmd` | 20 秒 | usbmmidd 虚拟屏**不跨重启保留**，必须先重新激活 |
| `ResProbe Guard` | `常驻守卫.cmd` | 60 秒 | 常驻守卫，需等虚拟屏就绪后再启动 |

两者均为「登录时触发 + 最高权限」（改显示拓扑需要管理员）。
注册前会用 `Get-ScheduledTask | Where-Object { $_.TaskName -like 'ResProbe*' }` 清理
**所有** `ResProbe` 前缀任务，因此历史上任何命名（中文或英文）的残留都会被清掉。

> 任务名保持英文：中文任务名必须写进脚本内容，违反纯 ASCII 约束。
> 脚本路径由内容里的 ASCII 标记行发现（见 §3），而不是硬编码中文文件名。

---

## 6. 接口与函数约定

以下均为 `namespace resprobe` 内的自由函数，头文件见 `src/`。

### 6.1 `edid.h`

```cpp
// 规范化 DisplayConfig 监视器路径为设备实例 ID
std::wstring NormalizeMonitorDevicePath(const std::wstring& path);

// 键为大写化的设备实例 ID
std::map<std::wstring, EdidInfo> EnumerateMonitorEdid(std::wstring* diagOut = nullptr);

EdidInfo ParseEdid(const std::vector<BYTE>& bytes);
```

### 6.2 `display.h`

```cpp
// includePlaceholderPaths=false 时只返回"有意义"的输出
std::vector<DisplayTarget> EnumerateDisplays(UINT32 refW, UINT32 refH,
                                             std::wstring* diagOut = nullptr,
                                             int* totalPathsOut = nullptr,
                                             bool includePlaceholderPaths = false);

DisplaySnapshot CaptureSnapshot(const std::string& trigger, UINT32 refW, UINT32 refH);
DisplayPowerState InferPowerStateFromTopology(const std::vector<DisplayTarget>& targets);
std::wstring PrimaryModeText(const DisplaySnapshot& snap);

// 虚拟显示判断：优先看 adapterDevicePath，退化到 gdiDeviceString，再看镜像驱动标志
bool IsVirtualDisplayTarget(const DisplayTarget& t);

// 输出：changedFields=机器可读字段，transitions=人类可读迁移
void DiffSnapshots(const DisplaySnapshot& before, const DisplaySnapshot& after,
                   std::vector<std::string>* changedFields,
                   std::vector<std::string>* transitions);
```

### 6.3 `session.h`

```cpp
SessionInfo QuerySessionInfo();
std::vector<RemoteSoftwareInfo> DetectRemoteSoftware(const std::vector<DisplayTarget>& targets);
bool IsProcessElevated();
```

### 6.4 `verify.h`

```cpp
ModeProbe ProbeModeAvailability(const DisplayTarget& t, UINT32 width, UINT32 height,
                                bool useCdsTest);

// 依次尝试 3 种 DEVMODE 组合；attempts 可空
LONG ApplyDisplayMode(const std::wstring& gdiDeviceName, UINT32 width, UINT32 height,
                      UINT32 refreshHz, bool permanent,
                      std::vector<ApplyAttempt>* attempts = nullptr);

RestoreOutcome RestoreReferenceMode(const DisplaySnapshot& before, UINT32 refW, UINT32 refH);

// 目标屏落 (0,0) 并设为指定分辨率，其余输出依次右移；最后统一提交
bool ArrangeDesktopLayout(const std::wstring& primaryGdi, UINT32 width, UINT32 height,
                          UINT32 refreshHz, std::vector<ApplyAttempt>* log,
                          std::wstring* message);

// 返回 ERROR_SUCCESS / Win32 错误码；不允许摘成空桌面
LONG DetachOutputs(const std::vector<std::wstring>& gdiDeviceNames);

// 提升虚拟屏为参考分辨率主屏并摘除死输出
PromoteOutcome PromoteVirtualDisplay(UINT32 width, UINT32 height, bool detachDeadOutputs);

// 拓扑状态汇总（供 ensure 做幂等决策）
struct TopologyState {
    int totalActive = 0;
    int activeVirtualCount = 0;     // 活动中的虚拟显示输出数量
    int healthyPhysicalCount = 0;   // 有 EDID 的非虚拟活动输出
    int deadPhysicalCount = 0;      // 无 EDID 且分辨率低于参考值的活动输出
    std::vector<std::wstring> activeVirtualDevices;
    std::vector<std::wstring> deadPhysicalDevices;
    std::wstring primaryGdiDevice;
    std::wstring primaryMode;
};
TopologyState EvaluateTopology(UINT32 refW, UINT32 refH);

LONG ApplyCloneTopology();    // SDC_APPLY | SDC_TOPOLOGY_CLONE
LONG ApplyExtendTopology();   // SDC_APPLY | SDC_TOPOLOGY_EXTEND

bool ReadPeerSummary(const std::wstring& path, PeerSummary* out);
```

### 6.5 `ensure` 子命令的契约

`ensure` 是给脚本调用的**幂等**入口，退出码是主要接口（脚本无需解析中文输出）：

| 退出码 | 含义 | 调用方应采取的动作 |
|---|---|---|
| `0` | **兜底能力已就位**（有虚拟显示器，且主屏达到参考分辨率、桌面无断链死输出） | 无需动作 |
| `20` | 没有可用的虚拟显示输出 | 执行 `deviceinstaller64.exe enableidd 1` 后重试 |
| `21` | 已调整，但主屏仍未达到参考分辨率 | 人工介入排查（驱动/拓扑异常） |
| `1` | 参数或执行失败 | 人工介入 |

**退出码 0 的语义是「兜底能力就位」，不是「当前桌面看着正常」。** 这一点很关键：
显示器开着的时候桌面本来就是 1920×1080，而此刻虚拟屏可能压根不存在，
物理屏一旦断电又会掉回 1024×768。因此虚拟屏的存在性是返回 0 的**前置条件**。

行为：

1. **前置检查：虚拟显示输出是否存在**（与当前桌面状态无关）。
   判据取两个信号的并集：全量路径里虚拟适配器上存在 `active` / `targetAvailable`
   的目标，或拓扑汇总里已识别出活动的虚拟输出。
   若为 0 → 打印提示并返回 **20**；
2. 采集拓扑，打印状态（活动/健康物理/断链物理计数、主屏、可用虚拟输出数）；
3. **就绪判据**：`主屏分辨率 == 参考分辨率` 且 `deadPhysicalCount == 0`
   → 直接返回 0，**不做任何改动**（这是幂等的关键）；
4. 否则按 `--mode` 决策：`promote` → 提升虚拟屏；`mirror` → 应用复制拓扑；
   `auto` → 有健康物理屏则镜像，否则提升（镜像失败会退化为提升，保证主屏正确）；
5. 复核并返回 0 / 21。

> 关于判据为什么刻意不依赖"虚拟屏识别"：克隆（镜像）拓扑下多个输出共用同一个 GDI
> 源名，DisplayConfig 会把克隆目标报在**源适配器**上，此时基于适配器/设备描述的识别
> 全部失效。所以第 3 步只用「主屏分辨率 + 有无断链死输出」，虚拟屏识别仅用于第 1 步
> 的存在性判断（那时它能工作，因为拓扑是扩展态或虚拟屏独立存在）。

### 6.6 `verdict.h`

```cpp
struct VerdictInput {
    const DisplaySnapshot* baseline = nullptr;
    const DisplaySnapshot* latest   = nullptr;
    const std::vector<EventRecord>* events = nullptr;   // 整条时间线，可空
    const SessionInfo* session      = nullptr;
    const std::vector<RemoteSoftwareInfo>* software = nullptr;
    const PeerSummary* peer         = nullptr;
    UINT32 refWidth = 1920, refHeight = 1080;
};

Verdict EvaluateVerdict(const VerdictInput& in);   // 纯函数，不改系统状态
```

### 6.7 `watcher.h`

```cpp
void RequestStop();       // 供控制台 Ctrl+C 处理器调用
bool StopRequested();

class Watcher {
public:
    explicit Watcher(Report& report);
    int Run();                                     // 0=正常结束
    void OnWindowMessage(HWND, UINT, WPARAM, LPARAM);
};
```

### 6.8 `report.h`

```cpp
std::wstring DefaultOutPath(const std::wstring& mode);
std::wstring DerivePeerPath(const std::wstring& outPath);

void PrintBanner();
void PrintSession(const SessionInfo&);
void PrintSnapshotConsole(const DisplaySnapshot&, bool verbose);
void PrintRemoteSoftware(const std::vector<RemoteSoftwareInfo>&);
void PrintProbes(const std::vector<ModeProbe>&);
void PrintEventConsole(const EventRecord&);
void PrintVerdict(const Verdict&);

bool WriteJsonReport(const Report&, const std::wstring& path);
bool WritePeerSummary(const Report&, const std::wstring& path);
```

### 6.9 JSON 报告结构

```jsonc
{
  "tool": "ResProbe", "version": "1.0.0", "mode": "watch",
  "startedUtc": "...", "finishedUtc": "...", "generatedUtc": "...",
  "diagnostics": "DisplayConfig: 146 条路径 / ...",
  "options": { "referenceWidth": 1920, "referenceHeight": 1080, "durationSec": 0,
               "intervalSec": 10, "settleMs": 800, "cdsTest": true, "writeConfirmed": false },
  "session": { "remoteSession": false, "protocolType": "Console", /* ... */ },
  "remoteSoftware": [ { "name": "...", "kind": "process|service|display-adapter|monitor-device",
                        "detail": "...", "isVirtualDisplay": false } ],
  "initialSnapshot": { /* DisplaySnapshot */ },
  "displayPowerNotifications": { "notificationCount": 1, "transitions": [ "..." ] },
  "events": [ { "index": 2, "timeUtc": "...", "uptimeMs": 12345,
                "trigger": "WM_DISPLAYCHANGE(1024x768 32bpp)",
                "changed": true, "changedFields": [ "..." ], "transitions": [ "..." ],
                "snapshot": { /* DisplaySnapshot */ } } ],
  "verification": [ { "gdiDeviceName": "\\\\.\\DISPLAY1", "listedInModeList": true,
                      "cdsTestPerformed": true, "cdsTestAccepted": true,
                      "degradedModeResolutions": [ "..." ] } ],
  "peer": { "present": false, "primaryMode": "", /* ... */ },
  "actionLog": [ "guard#1: 已完成虚拟屏提升；活动输出 1 个，主屏 1920x1080 (\\\\.\\DISPLAY46)" ],
  "restore": { "attempted": true, "succeeded": true, "resultName": "DISP_CHANGE_SUCCESSFUL",
               "attempts": [ "完整 DEVMODE（含色深/刷新率）+ 写入注册表 -> DISP_CHANGE_SUCCESSFUL" ] },
  "verdict": { "code": "LINK_LEVEL_FALLBACK", "blame": "link", "confidence": "high",
               "summary": "...", "reasons": [ "..." ], "recommendations": [ "..." ] }
}
```

`DisplaySnapshot` 关键字段：`timeUtc` / `uptimeMs` / `trigger` / `displayPowerState` /
`displayPowerStateInferred` / `remoteSession` / `sessionId` / `primaryGdiDevice` / `primaryMode` /
`totalPathCount` / `reportedTargetCount` / `targets[]`。

`DisplayTarget` 关键字段：`active` / `targetAvailable` / `targetStatusFlags` / `gdiDeviceName` /
`outputTechnology` / `monitorFriendlyName` / `monitorDevicePath` / `monitorInstanceId` /
`monitorDeviceNodePresent` / `currentMode` / `preferredMode` / `gdi{...}` / `modeList{...}` / `edid{...}`。

`edid{...}` 含 `present` / `valid` / `manufacturer` / `pnpIdRaw` / `productCode` /
`monitorName` / `preferredTiming` / `rawHex`（仅活动输出）。

### 6.10 对端摘要（`*.peer.json`）

扁平的键值结构，便于用最简解析器读取（`ReadPeerSummary` 只做按行键值提取，不做通用 JSON 解析）：

```jsonc
{ "tool": "ResProbe", "timeUtc": "...", "hostName": "...",
  "remoteSession": false, "primaryMode": "1920x1080", "primaryGdiDevice": "\\\\.\\DISPLAY1",
  "degraded": false, "activeTargets": [ { "gdiDeviceName": "...", "mode": "1920x1080",
                                          "edidPresent": true } ] }
```

**双端比对流程**：在被控端与远程客户端各跑一次 `snapshot`，把客户端产出的
`*.peer.json` 拷到被控端，执行 `resprobe verify --peer <该文件>`。

---

## 7. 部署与启动

### 7.1 构建

```bat
cd /d d:\nodejs\分辨率
编译.bat                 :: 等价于 mingw32-make
编译.bat clean           :: 清理
```

`编译.bat` 会注入 `MINGW_BIN`（默认 `C:\mingw64\bin`）到 PATH。若 MinGW 装在别处：

```bat
set MINGW_BIN=D:\mingw64\bin && 编译.bat
```

产物：`resprobe.exe`（控制台子系统，务必**不要**加 `-mwindows`）。

### 7.2 推荐流程（脚本方式，优先用这套）

```bat
:: 首次部署（幂等，可重复执行）
安装.cmd

:: 注册开机自启（默认：常驻守卫）
开机自启.cmd

:: 立刻启动常驻守卫（不等下次登录）
常驻守卫.cmd /bg

:: 无显示器 / 显示器不再接回：一次性把虚拟屏定为唯一主屏
一次性启动.cmd

:: 卸载
卸载.cmd            :: 保留驱动，可重装
卸载.cmd /full      :: 连驱动一起移除
```

### 7.3 底层命令（排查与手工操作用）

```bat
:: 诊断（只读，无副作用）
resprobe.exe snapshot
resprobe.exe paths --verbose
resprobe.exe verify --peer samples\peer-degraded-1024x768.json

:: 幂等拓扑调整（脚本内部用的就是它，有退出码约定）
resprobe.exe ensure
resprobe.exe ensure --mode promote
resprobe.exe ensure --mode mirror

:: 监听与自动守卫
resprobe.exe watch --duration 0 --interval 10 --guard

:: 手动修复（会改变系统状态，需 --yes）
resprobe.exe vdisplay --yes --mirror      :: 显示器常开：镜像，桌面恒 1920x1080
resprobe.exe vdisplay --yes --promote     :: 显示器会断电：提升虚拟屏 + 摘除死输出
resprobe.exe restore --reference 1920x1080 --yes

:: 需要留证据时才写 JSON（默认不落盘）
resprobe.exe watch --duration 120 --interval 10 --guard --out repro.json

:: 直接操作虚拟屏（脚本已封装，一般不需要手工执行）
driver\usbmmidd_v2\deviceinstaller64.exe enableidd 1
driver\usbmmidd_v2\deviceinstaller64.exe enableidd 0
```

### 7.4 输出策略

- **默认不写任何 JSON。** 只有显式给出 `--out` 才落盘，避免污染项目目录。
- 所有落盘文件统一进 **`OUT\`**（可用 `--out-dir` 覆盖，或用带目录的 `--out` 指定绝对路径）。
- 脚本的日志也统一进 `OUT\`：`guard.log`（守卫）、`install-test.log` 等。
- `resprobe.exe` 的控制台输出是 **UTF-8**；用 PowerShell 读日志要加 `-Encoding UTF8`，
  否则中文会显示为乱码（文件本身没问题）。

---

## 8. 常见问题排查

### 8.1 编译相关

| 现象 | 原因 | 处理 |
|---|---|---|
| `cannot open output file resprobe.exe: Permission denied` | 有 `resprobe.exe` 进程在运行（守卫） | `Get-Process resprobe \| Stop-Process -Force` 后重编 |
| `'DISPLAYCONFIG_RATIONAL' has no member named 'numerator'` | 字段名大小写 | 用 `Numerator` / `Denominator` |
| `'AF_INET' was not declared` | `winsock2.h` 必须早于 `windows.h`，顺序冲突 | 已改用数值常量（2 / 23），不要引入 winsock2.h |
| `'DBT_DEVICEARRIVAL' was not declared` | `WIN32_LEAN_AND_MEAN` 下 `dbt.h` 不自动包含 | `common.h` 已显式 `#include <dbt.h>` |
| `'EnumerateDisplays' was not declared` | 漏包含 `display.h` | 在 `verify.cpp` 中已补 |

### 8.2 运行时 — 探测类

| 现象 | 排查 |
|---|---|
| `snapshot` 显示 `EDID=缺失` 但显示器明明开着 | ①确认显示器走的是 HDMI/DP 且链路正常；②用 `--verbose` 看 `monitorInstanceId` 是否为空；③检查 EDID 匹配是否退化为厂商+产品码 |
| `输出数` 极大（如 146） | 正常。`QDC_ALL_PATHS` 会返回大量占位路径；默认已过滤，`totalPathCount` 才是真实总数 |
| 电源状态始终 `UNKNOWN` | 未收到电源通知，正常回退到拓扑推断值（`displayPowerStateInferred`） |
| 远程软件识别出无关条目 | 关键词过宽（如旧版 `idd` 命中 `Middleware`）。收紧 `kVendors[]` 中的关键词 |

### 8.3 运行时 — 事件类

| 现象 | 排查 |
|---|---|
| 监听期间关闭显示器完全没有事件 | ①确认关的是**物理电源键**，不是系统省电关屏（后者不断链）；②确认窗口是顶层窗口而非 message-only；③看是否打印了 `[电源] 共收到 N 条...` |
| 变化发生了但报告里 `events` 为空 | 合并窗口逻辑问题：检查 `kMaxDeferFactor` 是否被改小/去掉 |
| 分辨率掉下去又恢复被判 `NOT_REPRODUCED` | 判定退化成首尾对比了。必须用整条时间线（`VerdictInput::events`） |

### 8.4 运行时 — 回写与虚拟屏

| 现象 | 原因 | 处理 |
|---|---|---|
| `CDS_TEST=预检通过` 但回写 `DISP_CHANGE_FAILED` | 链路已断，驱动拒绝在无接收端时提交模式 | **硬件限制，软件绕过不了**，只能靠虚拟屏兜底 |
| `SetDisplayConfig` 返回 `87` (`ERROR_INVALID_PARAMETER`) | `SDC_ALLOW_CHANGES` 与 `SDC_TOPOLOGY_*` 同用；`SDC_VALIDATE` 同理 | 用 `SDC_TOPOLOGY_*` 时**不要**带 `SDC_ALLOW_CHANGES`；只有配 `SDC_USE_SUPPLIED_DISPLAY_CONFIG` 时才加 |
| 守卫报 `DISP_CHANGE_SUCCESSFUL` 但死输出仍在 | 用了 `ChangeDisplaySettingsEx(NULL)` 摘除 | 必须走 `DetachOutputs()`（`SetDisplayConfig`） |
| 守卫反复空转 | 摘除未生效导致 `deadPhysical` 恒为真 | 同上；已加 8 秒冷却 |
| `vdisplay` 报「没有可用显示接收端」 | 虚拟显示器尚未创建（`targetAvailable` 全为 `false`） | 先跑 `deviceinstaller64 enableidd 1` |
| 镜像后桌面被压到 1024×768 | 克隆取共同分辨率，虚拟屏当时还是 1024×768 | 先把虚拟屏设到 1920×1080 再克隆 |
| 桌面上多出好几块屏 | `enableidd 1` 跑多次，最多 4 块 | `deviceinstaller64 enableidd 0` 逐块移除；或让守卫自动摘除 |
| 重启后虚拟屏消失 | usbmmidd 不跨重启保留 | 执行 `开机自启.cmd` 注册登录任务 |
| `ensure` 报 `虚拟 0，断链物理 2` 但实际上虚拟屏在跑 | 克隆拓扑下 DisplayConfig 把克隆目标报在**源适配器**上，`gdiDeviceString` / `adapterDevicePath` 都识别不出虚拟屏 | 已用「无 EDID 且分辨率不低于参考值」作为兜底判据（见 §4.7.5） |
| `adapterDevicePath` 对多个不同适配器返回同一个路径 | `DISPLAYCONFIG_DEVICE_INFO_GET_ADAPTER_NAME` 的 **`header.id` 必须为 0**，传 target id 会拿到错误结果 | 已修正，见 §4.1 |

### 8.6 脚本相关

| 现象 | 原因 | 处理 |
|---|---|---|
| 运行 `.cmd` 报 `锘緻echo off 不是内部或外部命令` | 文件带 UTF-8 **BOM**，首行被破坏 | 跑 `脚本编码修复.ps1`（去 BOM） |
| 运行 `.cmd` 报 `'xxx' 不是内部或外部命令`，且 `xxx` 是某条 `rem` 注释的后半截 | 文件里有**非 ASCII 字符**，cmd 按 OEM 代码页(936)解析时字节偏移错位 | 跑 `脚本编码修复.ps1`，它会报出具体字符与位置；改成纯 ASCII |
| 运行 `.cmd` 报 `) was unexpected at this time` | `if (...)` / `for ... do (...)` 块**空**了，或有未配对的括号 | 检查块体是否被编辑误删；括号内的字面括号要写 `^(` `^)` |
| 脚本输出的中文变乱码 | 脚本里写了中文（内容必须纯 ASCII） | 中文放文档，脚本用英文 |
| 日志里脚本输出乱码、但 `resprobe.exe` 的输出正常 | 内容仍含非 ASCII，两种编码混进同一个日志 | 同上；修好后日志统一为 UTF-8 |
| `call :Label` 找不到标签 | 批处理的 `call :label` **不能跨文件**调用 | 用独立脚本，或把逻辑内联 |
| `timeout /t N` 报 `Input redirection is not supported` | `timeout` 要求 stdin 是控制台；脚本输出被重定向时必然失败 | 改用 `powershell -NoProfile -Command "Start-Sleep -Seconds N" >nul 2>&1` |
| 链式命令里 `echo %ERRORLEVEL%` 永远打印 0 | `%VAR%` 在**整行解析时**就展开了，读到的是执行前的旧值 | 用 `cmd /v:on /c "... & echo !ERRORLEVEL!"`，或把命令拆成多行分别读 |
| 脚本自己匹配到了自己的标记 | `findstr` 未锚定行首，命中了注释里提到的标记文字 | 加 `/b` 锚定行首，并 `if /i not "!CAND!"=="%~f0"` 跳过自身 |
| `.ps1` 里中文乱码 | Windows PowerShell 5.1 对无 BOM 的 `.ps1` 按 ANSI 读取 | 本项目的 `.ps1` 刻意保持纯 ASCII |

> 一条命令检查 / 修复全部脚本：
> `powershell -NoProfile -ExecutionPolicy Bypass -File 脚本编码修复.ps1`
> 对目录下所有 `.cmd` / `.bat`：去 BOM →（必要时）GBK 转 UTF-8 → 去掉多余的
> `chcp 65001` 行 → 以 UTF-8 无 BOM 写回 → 报告残留的非 ASCII 字符。
> 全部干净退出 0，发现非 ASCII 退出 1。

### 8.5 环境相关经验

- **向日葵自带 OrayIddDriver 无法由外部激活**。驱动 `Started`、`enable_idd=1`、暴露 100 条占位路径，但 `targetAvailable` 全为 `false`。虚拟显示器必须由向日葵用户态程序（主控端远控工具栏「虚拟屏/多屏」）按需实例化。因此本项目改用 usbmmidd。
- 本机同时装有 VMware Workstation，设备树里会出现 `PCI\VEN_15AD&DEV_0405`（VMware SVGA，显示为「Microsoft 基本显示适配器 / Disconnected」）的残留设备，**与本工具无关**。

---

## 9. 后续扩展注意事项

### 9.1 结构性约束（不要破坏）

1. **`common.h` 必须是每个翻译单元的第一个头文件**。它定义了 `WIN32_LEAN_AND_MEAN` 与 `_WIN32_WINNT`，晚包含会导致 `QueryDisplayConfig` 等原型缺失。
2. **所有改系统状态的调用必须收敛在 `verify.cpp`**。诊断子命令（`snapshot` / `paths` / `verify`）宁可少报，也不能有副作用。
3. **`verdict.cpp` 保持纯函数**。不要在其中调用 Win32 状态修改 API，也不要引入 I/O。
4. **不要引入第三方依赖或 CMake**。当前设计刻意保持"拷走源码 + 有 g++ 就能编译"。
5. **`.cmd` / `.bat` 的文件名可以中文，但内容必须是纯 ASCII**（UTF-8 无 BOM）。
   理由见 §3 编码模型与 §8.6。任何编辑器保存时若加了 BOM、或写进了中文（哪怕注释），
   脚本立刻失效。改完脚本必须跑一次 `脚本编码修复.ps1` 校验。
   由此推导出的两条硬约束：**不能有中文名的被 `call` 的公共脚本**（配置内联）、
   **不能在脚本里硬编码中文文件名**（用 ASCII 标记行在运行时发现，见 §3）。
6. **`ensure` 的退出码是对外契约**，脚本依赖它做幂等判断。改退出码必须同步改每个脚本里的
   `CONFIG BLOCK` 与所有调用方；尤其是 `0 = 兜底能力就位` 的语义（要求虚拟屏存在），
   不要退回成"桌面当前看着正常就返回 0"，否则 `安装.cmd` 第 6 步会漏激活虚拟屏。
7. **`ensure` 的就绪判据（`primaryMode == 参考` 且 `deadPhysicalCount == 0`）不要放宽成"只要分辨率对就行"**，否则断链死输出会长期挂在桌面上污染桌面尺寸。

### 9.2 修改判定逻辑时

- 任何新增信号都要同时处理两种情况：**有历史变化过程** 和 **只有当前状态**（后者对应首次 `snapshot`）。
- 新增 `code` 时同步更新 §4.6 的判定码表，并考虑是否需要在 `recommendations` 中给出对应建议。
- 判定优先级是"双端比对 > 单机时间线"。改动时确认没有破坏这个顺序。
- 涉及 `blame` 字段时，注意它会被上游用于自动决策，取值限定在 `link` / `remote-software` / `none` / `unknown`。

### 9.3 修改事件监听时

- **新注册通知必须容错**：任一注册失败只打印提示，不能中断监听。
- **改动合并窗口要保留上限**，否则密集事件下会漏掉整个变化过程。
- **`TakeSample` 中的守卫逻辑依赖 `last_` 更新**，如果调整采样顺序，注意 `last_ = fixed` 的赋值不能丢。
- `kMaxEvents` 的"覆盖尾条目"策略保证了有界 + 终态准确，调大上限时注意内存与报告体积。

### 9.4 修改虚拟屏相关逻辑时

- 虚拟显示输出识别依赖适配器描述字符串匹配（`LooksLikeVirtualDisplayAdapter`）。**若要支持新的 IDD 厂商，把关键词加进这个函数**，同时同步 `session.cpp` 的 `kVendors[]`。
- **死输出判据必须用 `edid.present == false`**，不要用 `monitorDeviceNodePresent`。
- `DetachOutputs` 的"不允许摘成空桌面"保护不要移除。
- 守卫的冷却窗口（8 秒）是防止抖动期反复动作的关键，调小会增加系统扰动。

### 9.5 可选的后续增强

| 方向 | 状态 | 说明 |
|---|---|---|
| 幂等安装 / 卸载 / 启动 / 自启脚本 | ✅ 已实现 | `安装.cmd` / `卸载.cmd` / `一次性启动.cmd` / `常驻守卫.cmd` / `开机自启.cmd` |
| 输出统一到 `OUT\` 且默认不落 JSON | ✅ 已实现 | `--out` 显式开启，`--out-dir` 覆盖 |
| 幂等拓扑接口 | ✅ 已实现 | `resprobe ensure`，退出码 0 / 20 / 21 / 1 |
| 常驻服务化 | 未做 | 目前是前台进程 + 登录任务。改 Windows 服务需注意**服务会话无法操作桌面显示配置**，仍须运行在交互式会话 |
| 自动切回镜像 | 未做 | 显示器重新上电后目前依赖 Windows 自愈（实测能自动恢复镜像 1920×1080）。可加「物理屏恢复健康 → 主动切回镜像」 |
| 报告离线分析 | 未做 | 可加 `resprobe analyze <report.json>` 与轻量 JSON 解析，用于复盘历史故障 |
| 多显示器场景 | 未做 | 当前假设"单物理屏 + 虚拟屏"。多物理屏时 `PromoteVirtualDisplay` 的目标挑选策略需重新设计 |
| 无 usbmmidd 时降级 | 未做 | 可检测并提示改用向日葵虚拟屏（需主控端操作）或 RDP（`RdpIdd_IndirectDisplay` 系统自带，分辨率跟随客户端） |
| 清理多余虚拟屏 | 部分 | `ensure` 目前只在 promote 路径顺带摘除；克隆态下无法安全识别。彻底清理靠 `卸载.cmd` 的 `enableidd 0` ×4 |

### 9.6 交接清单

- [ ] `编译.bat` 能产出 `resprobe.exe`
- [ ] `resprobe.exe snapshot` 输出的 `EDID` / `模式数` / `首选模式` 与实机一致
- [ ] `resprobe.exe ensure` 返回 0（已就绪）
- [ ] `安装.cmd` 重复执行两次，第二次全部走 "skip" 分支（幂等验证）
- [ ] `driver\usbmmidd_v2\` 存在且含 `deviceinstaller64.exe` + `usbmmIdd.inf` + `x64\usbmmIdd.dll`
      （**不需要**依赖 `C:\Temp`，那里随时可能被清掉）
- [ ] 两个计划任务已注册（或明确不注册）：`开机自启.cmd /status`
- [ ] **知道如何停掉守卫进程**：`taskkill /im resprobe.exe /f`
      —— 它锁着 `resprobe.exe`，不停掉就无法重新编译
- [ ] 知道脚本编码模型：文件名可中文，**内容必须纯 ASCII**（§3 / §8.6）；
      改完脚本跑一次 `脚本编码修复.ps1`，退出码应为 0
- [ ] 知道共享配置块内联在 6 个脚本里（搜 `CONFIG BLOCK`），改动需同步
- [ ] 所有落盘产物都在 `OUT\`，日志用 `-Encoding UTF8` 读取
- [ ] 全新机器验证过一遍 `安装.cmd` 的第 4 步（创建设备节点）确实生效

---

## 10. 附录：验证方法与证据文件

### 10.1 三步复现与验证流程

```
① 关显示器前
   resprobe.exe snapshot

② 开着监听，物理关闭显示器，等 10 秒，再开回来
   resprobe.exe watch --duration 120 --interval 10 --guard

③ 关显示器后（保持关闭状态）
   resprobe.exe snapshot
```

**判定标准**：

| 观测项 | 正常（已修复） | 异常（未修复） |
|---|---|---|
| 主屏 | `1920×1080 @ (0,0)` | `1024×768` |
| 活动输出数 | **1**（仅虚拟屏） | 2~3（含死输出） |
| 桌面尺寸 | 恰为 `1920×1080` | `2048×768` / `3968×1080` 等 |
| `edid.present` | 虚拟屏为 `false`，物理屏已从桌面移除 | 死输出仍 `ACTIVE` |
| 守卫日志 | `DetachOutputs -> DISP_CHANGE_SUCCESSFUL (raw=0)` 且随后活动输出数=1 | 报成功但输出仍在 |

### 10.2 证据文件

> ⚠️ **2026-10-08 备注**：排查期间累积在 `OUT\evidence\` 下的那批历史报告已被清理
> （原因未查明，本机装有 360 安全软件，不排除外部清理工具所为）。这些文件都是
> `resprobe.exe` 的输出，**随时可以按 §10.1 的流程重新采集**，不影响功能。
>
> 如果后续需要长期留证，建议把证据目录移出本项目目录（例如放到 D 盘专门的数据盘），
> 避免被项目内的清理动作或安全软件波及。

**建议保留的证据**（按 §10.1 流程生成，命名后放入 `OUT\evidence\`）：

| 建议文件名 | 采集方式 | 内容 |
|---|---|---|
| `复现-首次.json` | 物理关显示器期间 `snapshot --out` | 完整根因证据链（EDID 消失、模式数 298→32、首选模式降级） |
| `守卫-接管.json` | `watch --duration 120 --interval 10 --guard --out` | `actionLog` 中守卫接管记录，判定为 `LINK_LEVEL_FALLBACK` |
| `守卫-日志.txt` | 守卫运行时的 `OUT\guard.log` | 虚拟屏提升 + 死输出摘除的逐条日志 |
| `链路断开回写.json` | 关显示器时 `restore --yes --out` | 三种 DEVMODE 变体全部 `DISP_CHANGE_FAILED` 的证据 |
| `路径盘点.json` | `paths --verbose --out` | 全量路径，含 Oray IDD / usbmmidd 适配器盘点 |

`samples\peer-*.json` 是双端比对样例夹具，**不属于证据**，保留在 `samples\`。

> 判断"修复是否生效"的判据见 §10.1 表；其中最关键的是**活动输出数必须为 1**。

### 10.3 关键 API 速查

| 用途 | API |
|---|---|
| 完整显示路径枚举 | `GetDisplayConfigBufferSizes` + `QueryDisplayConfig(QDC_ALL_PATHS, ...)` |
| 路径详情 | `DisplayConfigGetDeviceInfo`（`GET_TARGET_NAME` / `GET_SOURCE_NAME` / `GET_TARGET_PREFERRED_MODE`） |
| 顶层拓扑变更 | `SetDisplayConfig(SDC_APPLY \| SDC_TOPOLOGY_EXTEND/CLONE)` |
| 自定义配置 | `SetDisplayConfig(SDC_APPLY \| SDC_USE_SUPPLIED_DISPLAY_CONFIG \| SDC_ALLOW_CHANGES)` |
| 模式列表 / 当前模式 | `EnumDisplaySettingsExW` |
| 模式合法性预检 | `ChangeDisplaySettingsExW(..., CDS_TEST, ...)` |
| 单输出模式与位置 | `ChangeDisplaySettingsExW(..., DM_POSITION \| DM_PELSWIDTH \| DM_PELSHEIGHT, ...)` |
| EDID 读取 | `SetupDiGetClassDevsW(GUID_DEVCLASS_MONITOR)` + `SetupDiOpenDevRegKey` + `RegQueryValueExW(L"EDID")` |
| 显示器电源状态 | `RegisterPowerSettingNotification(hwnd, &GUID_CONSOLE_DISPLAY_STATE, ...)` |
| 监视器热插拔 | `RegisterDeviceNotificationW(hwnd, &filter /*GUID_DEVINTERFACE_MONITOR*/, ...)` |
| 会话信息 | `WTSQuerySessionInformationW` 系列 |
