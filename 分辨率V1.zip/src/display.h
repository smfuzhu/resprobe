// display.h - 显示输出拓扑 / 模式表 / EDID 关联探测
#pragma once

#include "common.h"

namespace resprobe {

// 枚举显示输出路径。
// 返回的列表中默认只包含“有意义”的输出：活动路径，或已连接监视器（有设备路径/EDID）的路径。
// includePlaceholderPaths=true 时返回全部路径（含未激活且未连接监视器的占位路径，
// 用于排查可被激活的虚拟/间接显示输出）。
// refW / refH 为“参考健康分辨率”，用于判断模式表中是否仍存在该模式。
// totalPathsOut 返回系统报告的路径总数。
std::vector<DisplayTarget> EnumerateDisplays(UINT32 refW, UINT32 refH,
                                             std::wstring* diagOut = nullptr,
                                             int* totalPathsOut = nullptr,
                                             bool includePlaceholderPaths = false);

// 判断某个输出是否由虚拟/间接显示适配器承载。
// 优先使用 adapterDevicePath：镜像拓扑下多个输出共用同一个 GDI 源名，
// 此时 gdiDeviceString 会串成物理适配器的描述，无法用于区分。
bool IsVirtualDisplayTarget(const DisplayTarget& t);

// 生成一次完整快照
DisplaySnapshot CaptureSnapshot(const std::string& trigger, UINT32 refW, UINT32 refH);

// 依据拓扑推断显示器电源状态（无电源事件时的兜底）
DisplayPowerState InferPowerStateFromTopology(const std::vector<DisplayTarget>& targets);

// 取当前主显示输出的模式文本
std::wstring PrimaryModeText(const DisplaySnapshot& snap);

// 差分：比较两个快照的差异
void DiffSnapshots(const DisplaySnapshot& before, const DisplaySnapshot& after,
                   std::vector<std::string>* changedFields,
                   std::vector<std::string>* transitions);

}  // namespace resprobe
