// verify.h - 模式可用性验证、回写与双端比对
#pragma once

#include "common.h"

namespace resprobe {

// 只读验证：目标分辨率是否存在于该输出的模式表中，以及驱动是否接受该模式。
// 注意：CDS_TEST 通过只说明该模式在列表内合法，并不保证当前链路实际可应用。
ModeProbe ProbeModeAvailability(const DisplayTarget& t, UINT32 width, UINT32 height,
                                bool useCdsTest);

// 一次回写尝试
struct ApplyAttempt {
    std::wstring description;
    LONG resultCode = 0;
    bool applied = false;
};

// 应用显示模式。会依次尝试多种 DEVMODE 组合，返回首个成功的返回码。
// 链路已断开（无 EDID / 无监视器设备节点）时，驱动通常会拒绝，此时返回最后一次失败码。
LONG ApplyDisplayMode(const std::wstring& gdiDeviceName, UINT32 width, UINT32 height,
                      UINT32 refreshHz, bool permanent,
                      std::vector<ApplyAttempt>* attempts = nullptr);

// 回写验证：尝试把主输出恢复到参考分辨率，返回执行结果描述
struct RestoreOutcome {
    bool attempted = false;
    bool succeeded = false;
    LONG resultCode = 0;
    std::wstring resultName;
    std::wstring before;
    std::wstring after;
    std::wstring message;
    std::vector<ApplyAttempt> attempts;
};
RestoreOutcome RestoreReferenceMode(const DisplaySnapshot& before, UINT32 refW, UINT32 refH);

// 多显示器布局：把 primaryGdi 放到桌面原点 (0,0) 并设为指定分辨率，其余输出依次右移。
// 用于虚拟显示器出现后，让远程软件捕捉到 1920x1080 的主画面。
bool ArrangeDesktopLayout(const std::wstring& primaryGdi, UINT32 width, UINT32 height,
                          UINT32 refreshHz, std::vector<ApplyAttempt>* log,
                          std::wstring* message);

// 把若干输出从桌面配置中摘除（用于链路已断、只剩回退分辨率的死输出）。
//
// 注意：ChangeDisplaySettingsEx(dev, NULL, ..., CDS_UPDATEREGISTRY, ...) 虽然会返回
// DISP_CHANGE_SUCCESSFUL，但实测并不会真正摘除输出，因此这里改用受支持的
// SetDisplayConfig + SDC_USE_SUPPLIED_DISPLAY_CONFIG，从活动配置里剔除对应路径。
// 至少会保留一个输出，避免摘成空桌面。
LONG DetachOutputs(const std::vector<std::wstring>& gdiDeviceNames);

// 把活动中的虚拟显示输出提升为参考分辨率主屏，并把断链死输出从桌面摘除。
// 用于物理显示器断电后，让桌面回到 1920x1080 且远程软件只看到这一块屏。
struct PromoteOutcome {
    bool performed = false;        // 是否真正执行了动作
    bool promoted = false;         // 虚拟屏是否成功设为主屏并达到目标分辨率
    std::wstring virtualDevice;
    std::wstring message;
    std::vector<std::string> log;
};

PromoteOutcome PromoteVirtualDisplay(UINT32 width, UINT32 height,
                                     bool detachDeadOutputs);

// 拓扑状态汇总（供 ensure 子命令做幂等决策）
struct TopologyState {
    int totalActive = 0;
    int activeVirtualCount = 0;     // 活动中的虚拟显示输出数量
    int healthyPhysicalCount = 0;   // 有 EDID 的非虚拟活动输出
    int deadPhysicalCount = 0;      // 无 EDID 的非虚拟活动输出
    std::vector<std::wstring> activeVirtualDevices;
    std::vector<std::wstring> deadPhysicalDevices;
    std::wstring primaryGdiDevice;
    std::wstring primaryMode;
};
TopologyState EvaluateTopology(UINT32 refW, UINT32 refH);

// 顶层拓扑切换
LONG ApplyCloneTopology();    // 复制（镜像）
LONG ApplyExtendTopology();   // 扩展

// 读取对端机器生成的 *.peer.json 摘要
bool ReadPeerSummary(const std::wstring& path, PeerSummary* out);

}  // namespace resprobe
